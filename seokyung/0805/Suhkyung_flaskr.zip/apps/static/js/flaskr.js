$(document).ready(function() {
    $('.modify-text').children('button').click(function() {
        $(this).parent().toggleClass('modify-text');
    });
});